package online_radio_database.exceptions;

public class InvalidSongArtistNameException extends InvalidSongException {
    public InvalidSongArtistNameException(String exception) {
        super(exception);
    }
}
