package online_radio_database.exceptions;

public class InvalidSongException extends IllegalArgumentException{
    public InvalidSongException(String exception) {super(exception);}
}
