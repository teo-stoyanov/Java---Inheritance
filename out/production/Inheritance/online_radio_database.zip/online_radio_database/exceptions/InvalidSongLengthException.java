package online_radio_database.exceptions;

public class InvalidSongLengthException extends InvalidSongException {
    public InvalidSongLengthException(String exception) {
        super(exception);
    }
}
